﻿using Repository;

namespace perfomance_cache.Controllers
{
    public class CategoryController
    {

        private readonly ICategoryRepository _categoryRepository;

        public CategoryController(CategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

    }
}
