﻿using Dapper;
using Domain;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using Newtonsoft.Json;
using Repository;
using StackExchange.Redis;

namespace perfomance_cache.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleController : ControllerBase
    {

        private const string key = "get-vehicles";
        private const string redisConn = "localhost:6379";
        private readonly IVehicleRepository _vehicleRepository;

        public VehicleController(IVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {

            var redis = ConnectionMultiplexer.Connect(redisConn);
            IDatabase db = redis.GetDatabase();
            await db.KeyExpireAsync(key, TimeSpan.FromMinutes(20)); 
            string userValue = await db.StringGetAsync(key);

            if (!string.IsNullOrEmpty(userValue))
            {
                return Ok(userValue);
            }
            
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            var userJson = JsonConvert.SerializeObject(vehicles);
            await db.StringSetAsync(key, userJson);
            Thread.Sleep(3000);
            return Ok(vehicles);
        }

        [HttpPost]

        public async Task<IActionResult> Post([FromBody] Vehicle v)
        {
            if (v == null)
                return BadRequest("Dados inválidos");

            using var connection = new MySqlConnection(dbConn);
            await connection.OpenAsync();

            string sql = @"
                insert into vehicles(brand, model, year, plate)
                values(@Brand ,@Model, @Plate, @Year);
                select last_insert_id();
            ";

            var newId = await connection.QuerySingleAsync<int>(sql, v);
            v.Id = newId;

            await InvalidateCache();

            return CreatedAtAction(nameof(Get), new {id = newId}, v);
           
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Vehicle v)
        {
            if (v == null)
                return BadRequest("Dados inválidos");

            using var connection = new MySqlConnection(dbConn);
            await connection.OpenAsync();

            v.Id = id;

            string sql = @"
                update vehicles set
                brand = @Brand,
                year = @Year,
                model = @Model,
                plate = @Plate
                where id = @id;
            ";

            var rowsAffected = await connection.ExecuteAsync(sql, v);

            if (rowsAffected == 0)
            {
                return NotFound("Nenhum veículo encontrado!");
            }

            await InvalidateCache();
            return NoContent();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest("Identificador não informado");
            }

            using var connection = new MySqlConnection(dbConn);
            await connection.OpenAsync();

            string sql = "DELETE FROM vehicles WHERE id = @Id";

            var rowsAffected = await connection.ExecuteAsync(sql, new {id});
            await InvalidateCache();

            return NoContent();


        }
        

        private async Task InvalidateCache()
        {
            var redis = ConnectionMultiplexer.Connect(redisConn);
            IDatabase db = redis.GetDatabase();
            await db.KeyDeleteAsync(key);
        }
    }
}
