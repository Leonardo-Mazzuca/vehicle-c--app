﻿
namespace Repository
{
    public interface ICategoryRepository
    {
    }
}
