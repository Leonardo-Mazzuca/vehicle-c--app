﻿

namespace Repository
{
    public class CategoryRepository : ICategoryRepository
    {
    }
}
